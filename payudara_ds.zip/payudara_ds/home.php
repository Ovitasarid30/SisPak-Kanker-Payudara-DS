<style type="text/css">
.art-post .art-post-body .art-post-inner.art-article .art-postcontent div p .active strong {
	color: #000;
}
.art-post .art-post-body .art-post-inner.art-article .art-postcontent div p .active strong br {
	color: #0000A0;
}
.art-post .art-post-body .art-post-inner.art-article .art-postcontent div p .active strong {
	color: #0000A0;
}
</style>
<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<div class="art-postcontent"> <table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><h3>SELAMAT DATANG DI WEBSITE SISTEM PAKAR DETEKSI DINI PENYAKIT KANKER PAYUDARA</h3><div align="center">
<p align="justify"><img id="gambar" style="float:left;" width="280" height="200" alt="" src="images/diagram gigi.jpg"></p>
<p>Payudara terbentuk dari lemak, <a href="http://www.alodokter.com/jaringan-ikat-manusia-bisa-kena-penyakit-penyakit-ini" target="_blank">jaringan ikat</a>,     dan ribuan lobulus (kelenjar kecil penghasil air susu). Saat seorang     wanita melahirkan, Air Susu Ibu (ASI) akan dikirim ke puting melalui     saluran kecil saat menyusui.</p>
<p>Sel-sel dalam tubuh kita biasanya tumbuh dan berkembang biak secara     teratur. Sel-sel baru hanya terbentuk saat dibutuhkan. Tetapi proses     dalam tubuh pengidap kanker akan berbeda.</p>
<p>Proses tersebut akan berjalan secara tidak wajar sehingga pertumbuhan     dan perkembangbiakan sel-sel menjadi tidak terkendali. Sel-sel   abnormal   tersebut juga bisa menyebar ke bagian-bagian tubuh lain   melalui aliran   darah. Inilah yang disebut kanker yang mengalami   metastasis.</p>
<p>Jika terdeteksi pada stadium awal, kanker dapat diobati sebelum     menyebar ke bagian lain tubuh. Gejala awal kanker payudara adalah     benjolan atau penebalan pada jaringan kulit payudara. Tetapi sebagian     besar benjolan belum tentu menandakan kanker.</p>
<h4><strong>Penderita Kanker Payudara di Indonesia</strong></h4>
<p>Kejadian kanker payudara di Indonesia mencapai sekitar 40 kasus     setiap 100.000 penduduk pada tahun 2012, menurut data di organisasi     kesehatan dunia (WHO). Dibandingkan dengan negara tetangga kita,     Malaysia, kanker payudara di Indonesia lebih banyak diderita oleh wanita     usia muda dan pada tahap yang lebih lanjut.</p>
<p>Kanker payudara tidak hanya menyerang kaum wanita tapi juga pria walaupun jarang.</p>
<p align="justify" class="style2">&nbsp;</p>
        </blockquote>
        </blockquote>
    </div></td>
  </tr>
</table></div>
<div class="cleared"></div>
</div>
		<div class="cleared"></div>
  </div>
</div>