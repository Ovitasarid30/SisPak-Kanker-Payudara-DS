<ul class="art-hmenu">
		<li>
			<a href="index.php?top=home.php"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
		</li>	
		<li>
			<a href="index.php?top=pasien_add_fm.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Proses Deteksi</span></a>
		</li>	
        <!-- <li>
			<a href="index.php?top=info.php"><span class="l"></span><span class="r"></span><span class="t">Informasi</span></a>
		</li> -->
        <li>
			<a href="index.php?top=about.php"><span class="l"></span><span class="r"></span><span class="t">Tentang</span></a>
		</li>
		<li>
			<a href="index.php?top=info-penyakit.php"><span class="l"></span><span class="r"></span><span class="t">Jenis Kanker Payudara</span></a>
		</li>		
		<li>
			<a href="admin/index.php"><span class="l"></span><span class="r"></span><span class="t">Login</span></a>
		</li>	
	</ul>