<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader">Help</h2>
<div class="art-postcontent">
<p><img src="images/help.jpg" alt="an image" width="142" height="132"  /></p>
<ul>
  <li>
    <h3><em>Menu Home</em></h3>
    <p>Menu Home digunakan untuk</p>
  </li>
  <li>
    <h3><em>Menu Konsultasi</em></h3>
  </li>
  <li>
    <h3><em>Menu Berita</em></h3>
  </li>
  <li>
    <h3><em>Menu Daftar Berita</em></h3>
  </li>
  <li>
    <h3><em>Menu Profil</em></h3>
  </li>
  <li>
    <h3><em>Tata Cara Melakukan Konsultasi</em></h3>
    <p>Pilih menu <strong>Konsultasi</strong> untuk melakukan konsultasi dengan sistem. Inputkan data diri anda pada form <strong>MASUKAN DATA PASIEN</strong> kemudian klik Daftar. kemudian pilih gejala-gejala yang anda alami dengan menconteng pada checkbox pada form <strong>KONSULTASI. </strong>kemudian tekan button <strong>Proses</strong> <strong>Diagnosa </strong>untuk mendiagnosa penyakit anda berdasarkan gejala yang anda input. Kemudian sistem akan menampilkan hasil diagnosis pada form <strong>HASIL ANALISA PENYAKIT PENCERNAAN.</strong></p>
  </li>
</ul>
<br>
<center>
  <strong>Terima kasih</strong>
</center>
</div>
                <div class="cleared"></div>
                </div>

		<div class="cleared"></div>
    </div>
</div>