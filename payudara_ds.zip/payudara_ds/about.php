<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader">About Programs</h2>
<div class="art-postcontent">
<p align="justify">Sistem pakar adalah sistem berbasis komputer yang menggunakan pengetahuan, fakta, dan teknik
  penalaran dalam memecahkan masalah yang biasanya hanya dapat dipecahkan oleh seorang pakar dalam
  bidang tertentu. Sistem pakar memberikan nilai tambah pada teknologi untuk membantu dalam era informasi yang 
  semakin canggih.
  Aplikasi Sistem Pakar ini menghasilkan keluaran berupa kemungkinan penyakit kanker payudara yang diderita
  berdasarkan gejala yang dirasakan oleh user. Besarnya nilai kepercayaan tersebut
  merupakan hasil perhitungan dengan menggunakan metode Dempster-Shafer.</p>
<table width="80%" height="172" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td width="84" class="style1">Nama</td>
    <td width="14" class="style1">:</td>
    <td width="225" class="style1">Ovitasari Dewi</td>
    <td width="157" rowspan="5" valign="top" class="style1"><img src="images/Admin.jpeg" width="156" height="170"></td>
  </tr>
  <tr>
    <td class="style1">NIM</td>
    <td class="style1">:</td>
    <td class="style1">3145162939</td>
  </tr>
  <tr>
    <td class="style1">Prodi</td>
    <td class="style1">:</td>
    <td class="style1">Ilmu Komputer</td>
  </tr>
  <tr>
    <td class="style1">TTL</td>
    <td class="style1">:</td>
    <td class="style1">Jakarta, 30 Oktober 1997</td>
  </tr>
</table>
</div>
<div class="cleared"></div>
</div>
		<div class="cleared"></div>
    </div>
</div>